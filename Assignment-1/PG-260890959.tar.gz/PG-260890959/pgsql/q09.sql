SELECT count(pname) AS numprojects
FROM project
WHERE pstartdate between '2021-01-01' and '2021-12-31';
