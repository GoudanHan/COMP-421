SELECT ename, employeeid
FROM developer
WHERE employeeid IN (SELECT employeeid
		     FROM devassignments
		     WHERE pname='Kodiak')
UNION
SELECT ename, employeeid
FROM developer
WHERE employeeid IN (SELECT employeeid
		     FROM documentauthors
		     WHERE documentid IN (SELECT documentid
					  FROM document
					  WHERE pname='Kodiak'))
ORDER BY employeeid;
