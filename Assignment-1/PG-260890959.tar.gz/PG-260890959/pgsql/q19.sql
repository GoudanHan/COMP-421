DELETE
FROM devassignments
WHERE employeeid=81532 AND pname='Haddock'; 
