SELECT DISTINCT pname
FROM devassignments
WHERE pname IN (SELECT pname
		FROM devassignments
		GROUP BY pname
		HAVING count(employeeid)>2)
ORDER BY pname;
