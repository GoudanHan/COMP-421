SELECT pname, count(documentid) AS numdocs
FROM document
WHERE pname IN (SELECT pname
		FROM project
		WHERE ptype='internal')
GROUP BY pname
UNION
SELECT pname, 0 AS numdocs
FROM project
WHERE ptype='internal' AND pname NOT IN(SELECT pname FROM document)
ORDER BY numdocs DESC, pname;
