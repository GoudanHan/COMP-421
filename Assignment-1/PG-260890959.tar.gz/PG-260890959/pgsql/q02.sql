SELECT employeeid, ename
FROM developer
WHERE employeeid IN (SELECT employeeid
	FROM documentauthors
	WHERE documentid = 22)
ORDER BY employeeid;
