SELECT count(DISTINCT pname) AS numprojects
FROM document
WHERE documentid IN (SELECT documentid
        	     FROM documentauthors
        	     WHERE employeeid=93401);
