(SELECT DISTINCT pname
FROM devassignments
EXCEPT
SELECT DISTINCT pname
FROM devassignments D1
WHERE pname IN (SELECT pname
                FROM devassignments
                GROUP BY pname
                HAVING count(employeeid)>2))
UNION(
SELECT pname
FROM project
EXCEPT
SELECT DISTINCT pname
FROM devassignments)
ORDER BY pname;
