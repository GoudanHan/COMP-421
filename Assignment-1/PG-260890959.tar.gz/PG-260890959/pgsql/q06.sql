SELECT employeeid, ename
FROM developer
WHERE employeeid IN (SELECT employeeid
		     FROM devassignments
		     WHERE pname IN (SELECT pname
				     FROM project
				     WHERE ptype='internal')
		     EXCEPT
		     SELECT employeeid
        	     FROM devassignments
        	     WHERE pname IN (SELECT pname
                		     FROM project
                		     WHERE ptype='external'))
ORDER BY employeeid;
