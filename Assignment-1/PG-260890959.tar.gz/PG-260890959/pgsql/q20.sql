SELECT * from devassignments;
