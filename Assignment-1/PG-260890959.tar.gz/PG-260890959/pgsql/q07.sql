SELECT DISTINCT pname, employeeid
FROM (SELECT employeeid, documentauthors.documentid, pname
	FROM documentauthors, document
	WHERE documentauthors.documentid = document.documentid
	EXCEPT
	SELECT employeeid, documentid, document.pname
	FROM devassignments, document
	WHERE devassignments.pname = document.pname) AS derivedTable
ORDER BY pname, employeeid;
