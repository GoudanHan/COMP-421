SELECT ename, employeeid
FROM developer
WHERE employeeid IN ((SELECT employeeid
		     FROM devassignments
		     WHERE pname='Kodiak')
		     EXCEPT
		     (SELECT employeeid
		      FROM documentauthors
		      WHERE documentid IN (SELECT documentid
					   FROM document
					   WHERE document.pname='Kodiak')))
ORDER BY employeeid;
