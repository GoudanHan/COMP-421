SELECT devassignments.pname, asgndate, ptype
FROM devassignments, project
WHERE employeeid=82102 AND project.pname=devassignments.pname
ORDER BY pname
