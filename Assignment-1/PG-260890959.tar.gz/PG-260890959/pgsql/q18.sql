SELECT pname, devcost
FROM (SELECT devassignments.pname, budget, count(employeeid), budget/count(employeeid) AS devcost
	FROM project, devassignments
	WHERE project.pname=devassignments.pname
	GROUP BY devassignments.pname, budget) AS derivedTable
WHERE devcost = (SELECT MAX(devcost)
	       	 FROM (SELECT devassignments.pname, budget, count(employeeid), budget/count(employeeid) AS devcost
        		FROM project, devassignments
        		WHERE project.pname=devassignments.pname
        		GROUP BY devassignments.pname, budget) AS derivedTable)
ORDER BY pname;
