SELECT project.pname, pstartdate, count(employeeid) AS numdevs
FROM project, devassignments
WHERE pstartdate = (SELECT MAX(pstartdate) FROM project) AND project.pname=devassignments.pname
GROUP BY project.pname
UNION
SELECT project.pname, pstartdate, 0 AS numdevs
FROM project, devassignments
WHERE pstartdate = (SELECT MAX(pstartdate) FROM project) AND project.pname NOT IN (SELECT devassignments.pname FROM devassignments)
ORDER BY pname;
