SELECT DISTINCT pname
FROM document
WHERE documentid IN (SELECT documentid
	FROM documentauthors
	WHERE employeeid=93401)
ORDER BY pname;
